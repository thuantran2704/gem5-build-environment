import argparse
import os

import m5
from m5.objects import (
    ArmO3CPU,
    Cache,
    SystemXBar,
    SrcClockDomain,
    VoltageDomain,
    AddrRange,
    L2XBar,
    LocalBP,
    BiModeBP,
    TournamentBP,
    GshareBP,
    Root,
    Process,
    SEWorkload,
    DDR4_2400_8x8,
    MemCtrl,
)

from gem5.isas import ISA
from gem5.components.processors.base_cpu_core import BaseCPUCore
from gem5.components.processors.base_cpu_processor import BaseCPUProcessor

# ---------------- ARGS ----------------
parser = argparse.ArgumentParser()
parser.add_argument("--binary", required=True)
parser.add_argument("--input", required=True)
parser.add_argument("--l2_size", default="256KiB")
parser.add_argument("--l3_size", default=None)
parser.add_argument("--l2_assoc", type=int, default=16)
parser.add_argument("--l3_assoc", type=int, default=16)
args = parser.parse_args()

# ---------------- CPU CLASSES ----------------
class MyOutOfOrderCore(BaseCPUCore):
    def __init__(self, width, rob_size, num_int_regs, num_fp_regs, bp_type):
        core = ArmO3CPU()
        core.fetchWidth = width
        core.decodeWidth = width
        core.renameWidth = width
        core.dispatchWidth = width
        core.issueWidth = width
        core.wbWidth = width
        core.commitWidth = width
        core.numROBEntries = rob_size
        core.numPhysIntRegs = num_int_regs
        core.numPhysFloatRegs = num_fp_regs

        if bp_type == "LocalBP":
            cond_pred = LocalBP()
        elif bp_type == "BiModeBP":
            cond_pred = BiModeBP()
        else:
            cond_pred = TournamentBP()

        bp = GshareBP()
        bp.conditionalBranchPred = cond_pred
        core.branchPred = bp

        super().__init__(core, ISA.ARM)

class MyOutOfOrderProcessor(BaseCPUProcessor):
    def __init__(self, width, rob_size, num_int_regs, num_fp_regs, bp_type):
        super().__init__(
            cores=[MyOutOfOrderCore(width, rob_size, num_int_regs, num_fp_regs, bp_type)]
        )

# ---------------- CACHE CLASSES ----------------
# Added response_latency to all classes to satisfy gem5 check
class L1ICache(Cache):
    size = "32KiB"
    assoc = 4
    tag_latency = 1
    data_latency = 1
    response_latency = 1
    mshrs = 4
    tgts_per_mshr = 16

class L1DCache(Cache):
    size = "32KiB"
    assoc = 4
    tag_latency = 1
    data_latency = 1
    response_latency = 1
    mshrs = 4
    tgts_per_mshr = 16

class L2Cache(Cache):
    size = args.l2_size
    assoc = args.l2_assoc
    tag_latency = 10
    data_latency = 10
    response_latency = 10
    mshrs = 16
    tgts_per_mshr = 16

class L3Cache(Cache):
    size = args.l3_size if args.l3_size else "1B" # Cannot be 0B in some gem5 versions
    assoc = args.l3_assoc
    tag_latency = 20
    data_latency = 20
    response_latency = 20
    mshrs = 32
    tgts_per_mshr = 16

# ---------------- SYSTEM ----------------
system = m5.objects.System()
system.clk_domain = SrcClockDomain(clock="3GHz", voltage_domain=VoltageDomain())
system.mem_mode = "timing"
system.mem_ranges = [AddrRange("4GiB")]

system.membus = SystemXBar()
system.l2bus = L2XBar()

# Setup Processor
system.processor = MyOutOfOrderProcessor(
    width=8,
    rob_size=192,
    num_int_regs=256,
    num_fp_regs=256,
    bp_type="LocalBP"
)

cpu_node = system.processor.get_cores()[0].core
cpu_node.createInterruptController()

# Instantiate Caches
cpu_node.icache = L1ICache()
cpu_node.dcache = L1DCache()
system.l2cache = L2Cache()

# Connections
cpu_node.icache.cpu_side = cpu_node.icache_port
cpu_node.dcache.cpu_side = cpu_node.dcache_port
cpu_node.icache.mem_side = system.l2bus.cpu_side_ports
cpu_node.dcache.mem_side = system.l2bus.cpu_side_ports
system.l2cache.cpu_side = system.l2bus.mem_side_ports

if args.l3_size:
    system.l3bus = L2XBar()
    system.l3cache = L3Cache()
    system.l2cache.mem_side = system.l3bus.cpu_side_ports
    system.l3cache.cpu_side = system.l3bus.mem_side_ports
    system.l3cache.mem_side = system.membus.cpu_side_ports
else:
    system.l2cache.mem_side = system.membus.cpu_side_ports

# ---------------- MEMORY ----------------
system.mem_ctrl = MemCtrl()
system.mem_ctrl.dram = DDR4_2400_8x8(range=system.mem_ranges[0])
system.mem_ctrl.port = system.membus.mem_side_ports

# ---------------- WORKLOAD ----------------
binary_path = args.binary
system.workload = SEWorkload.init_compatible(binary_path)

process = Process()
process.cmd = [args.binary, args.input]
cpu_node.workload = process

# ---------------- RUN ----------------
root = Root(full_system=False, system=system)
m5.instantiate()

print(f"--- Starting simulation: L2={args.l2_size}, L3={args.l3_size if args.l3_size else 'None'} ---")
exit_event = m5.simulate()
print(f"Exiting @ tick {m5.curTick()} because {exit_event.getCause()}")