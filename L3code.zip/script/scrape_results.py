import os
import csv
import re

# --- SETTINGS ---
RESULTS_DIR = "results/"
OUT_CSV = "final_results.csv"
OUT_TXT = "final_results.txt"

# Mapping for your manual 'system' hierarchy in base_arch_new.py
STAT_MAP = {
    "Total Instructions": "simInsts",
    "Sim Ticks": "simTicks",
    "CPI": "system.processor.cores.core.cpi",
    "IPC": "system.processor.cores.core.ipc",
    "L1D Miss Rate": "system.processor.cores.core.dcache.overallMissRate::total",
    "L1I Miss Rate": "system.processor.cores.core.icache.overallMissRate::total",
    "L2 Miss Rate": "system.l2cache.overallMissRate::total",
    "L3 Miss Rate": "system.l3cache.overallMissRate::total",
    "DRAM Read BW": "system.mem_ctrl.dram.avgRdBW"
}

def extract_stat(text, key):
    """Finds the numeric value for a specific key in the stats file."""
    pattern = rf"^{re.escape(key)}\s+([0-9.eE+-]+)"
    match = re.search(pattern, text, re.MULTILINE)
    return match.group(1) if match else "NaN"

def run_scraper():
    # Full header for all your variables
    header = ["Folder", "Dataset", "L2_Size", "L3_State", "BP_Type"] + list(STAT_MAP.keys())
    rows = [header]
    txt_output_lines = []

    if not os.path.exists(RESULTS_DIR):
        print(f"Error: {RESULTS_DIR} not found.")
        return

    # Get every folder in results/
    all_folders = sorted([f for f in os.listdir(RESULTS_DIR) if os.path.isdir(os.path.join(RESULTS_DIR, f))])

    for folder in all_folders:
        folder_path = os.path.join(RESULTS_DIR, folder)
        stats_path = os.path.join(folder_path, "stats.txt")

        if not os.path.exists(stats_path):
            continue

        with open(stats_path, "r") as f:
            content = f.read()

        # Parse folder name (e.g., medium_L2_1MiB_L3_4MiB_LocalBP)
        parts = folder.split("_")
        
        # Metadata Extraction
        dataset = parts[0] if len(parts) > 0 else "n/a"
        l2 = "n/a"
        l3 = "None"
        bp = "LocalBP"

        if "L2" in parts:
            idx = parts.index("L2")
            if idx + 1 < len(parts): l2 = parts[idx+1]
        
        if "L3" in parts:
            idx = parts.index("L3")
            if idx + 1 < len(parts): l3 = parts[idx+1]
        elif "noL3" in parts:
            l3 = "None"

        # Special case for branch predictor names if they appear
        if any(x in folder for x in ["Tournament", "BiMode", "Local"]):
            bp = [x for x in ["Tournament", "BiMode", "Local"] if x in folder][0]

        # Extract stats into row
        data_row = [folder, dataset, l2, l3, bp]
        txt_output_lines.append(f"=== {folder} ===")
        
        for label, key in STAT_MAP.items():
            val = extract_stat(content, key)
            data_row.append(val)
            txt_output_lines.append(f"{label:20}: {val}")

        txt_output_lines.append("-" * 45)
        rows.append(data_row)

    # Write CSV for your spreadsheet analysis
    with open(OUT_CSV, "w", newline="") as f:
        csv.writer(f).writerows(rows)

    # Write TXT for a quick scroll-through
    with open(OUT_TXT, "w") as f:
        f.write("\n".join(txt_output_lines))

    print(f"\nScrape Complete!")
    print(f"Processed: {len(rows)-1} simulation results.")
    print(f"Outputs: {OUT_CSV} (Spreadsheet) and {OUT_TXT} (Human-readable)")

if __name__ == "__main__":
    run_scraper()