import os
import subprocess

# --- CONFIGURATION ---
GEM5_BIN = "/workspace/gem5_base/build/ARM/gem5.opt"
CONFIG = "/workspace/demo/base_arch_new.py"
BINARY = "/workspace/demo/bin/dijkstra"

# The three data levels
datasets = {
    "small": "/workspace/demo/data/small.txt",
    "medium": "/workspace/demo/data/medium.txt",
    "large": "/workspace/demo/data/large.txt"
}

# The two hardware configs to compare
configs = [
    ("256KiB", None, "noL3"),
    ("1MiB", "4MiB", "L3_4MiB")
]

os.makedirs("results", exist_ok=True)

# --- EXECUTION ---
for d_name, d_path in datasets.items():
    for l2, l3, l3_tag in configs:
        
        run_name = f"{d_name}_L2_{l2}_{l3_tag}_LocalBP"
        outdir = os.path.join("results", run_name)
        os.makedirs(outdir, exist_ok=True)

        cmd = [
            GEM5_BIN,
            f"--outdir={outdir}",
            CONFIG,
            f"--binary={BINARY}",
            f"--input={d_path}",
            f"--l2_size={l2}",
        ]

        if l3:
            cmd.append(f"--l3_size={l3}")

        print("\n" + "=" * 60)
        print(f"RUNNING: {run_name}")
        print("=" * 60)
        
        try:
            subprocess.run(cmd, check=True)
        except subprocess.CalledProcessError:
            print(f"FAILED: {run_name}")

print("\nAll Scaling Experiments Complete.")